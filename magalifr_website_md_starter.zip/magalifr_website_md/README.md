# Draft website markdown files

These are starter files for `MagaliFr/MagaliFr.github.io`.

- Copy files in `_pages/` into the repository's `_pages/` directory.
- Replace the existing project collection in `_projects/` with your own project files, or remove the old inherited template project files so they do not continue to appear.
- Project images are intentionally omitted for now. Add `img: assets/img/<filename>` to each project front matter when ready.
- `publications.md` is not included because the al-folio theme already generates publications from `_bibliography/papers.bib`.
- Search for `TODO` comments to find easy places to add content later.
